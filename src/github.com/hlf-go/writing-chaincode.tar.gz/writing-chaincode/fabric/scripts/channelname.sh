#!/bin/bash

CHANNELNAME="mychannel"